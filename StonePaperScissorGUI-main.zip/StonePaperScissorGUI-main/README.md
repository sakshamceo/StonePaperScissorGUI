# Stone Paper Scissor Python GUI
making a simplest Stone Paper Scissor Appl. using Tkinter liberary on Python
## Please Star this Repo.
![image](https://user-images.githubusercontent.com/59284238/119581275-de4ee080-bddf-11eb-903f-cfc3a5ad2b06.png)
## Thanks !
